import {
  COMMISSION_MAIN_TABLE,
  COMMISSION_SPECIAL_TABLE,
  COMMISSION_PERHEAD_TABLE,
  THAI_MONTHS,
} from '../data/constants';
import {
  CommissionBreakdown,
  GallonIncentiveResult,
  GallonIncentiveRule,
  SaleEntry,
} from '../types';

export function todayISO(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function monthKey(dateStr: string): string {
  if (!dateStr) return todayISO().slice(0, 7);
  return dateStr.slice(0, 7);
}

export function daysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

export function daysBetween(d1: string, d2: string): number {
  const t1 = new Date(d1).getTime();
  const t2 = new Date(d2).getTime();
  return Math.round((t2 - t1) / 86400000);
}

export function daysBetweenInclusive(d1: string, d2: string): number {
  return Math.abs(daysBetween(d1, d2)) + 1;
}

export function thaiMonthName(mKey: string): string {
  const parts = mKey.split('-');
  const m = parseInt(parts[1], 10);
  return THAI_MONTHS[m - 1] || mKey;
}

export function buddhistYear(year: number): number {
  return year + 543;
}

export function thaiFullDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length < 3) return dateStr;
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  const d = parseInt(parts[2], 10);
  return `${d} ${THAI_MONTHS[m - 1]} ${buddhistYear(y)}`;
}

export function thaiMonthYear(mKey: string): string {
  const parts = mKey.split('-');
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10);
  return `${THAI_MONTHS[m - 1]} ${buddhistYear(y)}`;
}

export function fmt(n: number): string {
  return (Number(n) || 0).toLocaleString('th-TH', { maximumFractionDigits: 0 });
}

export function fmtDec(n: number): string {
  return (Number(n) || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function lookupTiered(table: { pct: number; amt: number }[], pct: number): number {
  let amt = 0;
  for (const t of table) {
    if (pct >= t.pct) amt = t.amt;
  }
  return amt;
}

export function commissionInSpecialBand(target: number): boolean {
  return target >= 200000 && target <= 400000;
}

export function calcMainCommission(pct: number): number {
  return pct >= 80 ? lookupTiered(COMMISSION_MAIN_TABLE, pct) : 0;
}

export function calcSpecialCommission(pct: number, target: number): number {
  if (!commissionInSpecialBand(target)) return 0;
  return pct >= 80 ? lookupTiered(COMMISSION_SPECIAL_TABLE, pct) : 0;
}

export function calcPerHeadCommission(sales: number, headcount: number, pctReached: boolean): number {
  if (!pctReached) return 0;
  const hc = headcount > 0 ? headcount : 1;
  const perPerson = sales / hc;
  for (const t of COMMISSION_PERHEAD_TABLE) {
    if (perPerson >= t.min) return t.amt;
  }
  return 0;
}

export function calcCommissionBreakdown(
  target: number,
  sales: number,
  headcount: number
): CommissionBreakdown {
  const pct = target > 0 ? (sales / target) * 100 : 0;
  const monthGoalReached = pct >= 80;
  const main = calcMainCommission(pct);
  const special = calcSpecialCommission(pct, target);
  const hc = headcount > 0 ? headcount : 1;
  const perPersonSales = sales / hc;
  const perHead = calcPerHeadCommission(sales, hc, monthGoalReached);

  return {
    pct,
    main,
    special,
    perHead,
    perPersonSales,
    headcount: hc,
    monthGoalReached,
    total: main + special + perHead,
    inSpecialBand: commissionInSpecialBand(target),
  };
}

export function calcGallonIncentive(
  rules: GallonIncentiveRule[],
  monthSales: SaleEntry[],
  headcount: number
): GallonIncentiveResult {
  const rows = (rules || []).map((rule) => {
    const qty = monthSales
      .filter((s) => {
        if (s.name !== rule.name) return false;
        if (rule.size && s.size !== rule.size) return false;
        if (rule.base === '__ALL__') return true;
        if (Array.isArray(rule.base)) return rule.base.includes(s.base || '');
        return (s.base || '') === (rule.base || '');
      })
      .reduce((a, s) => a + (Number(s.qty) || 0), 0);

    const amount =
      rule.mode === 'perBundle' && (rule.bundleSize || 0) > 0
        ? Math.floor(qty / (rule.bundleSize || 1)) * (rule.value || 0)
        : qty * (rule.value || rule.ratePerCan || 0);

    return { rule, qty, amount };
  });

  const subtotal = rows.reduce((a, x) => a + x.amount, 0);
  const hc = headcount > 0 ? headcount : 1;
  const perPersonRaw = subtotal / hc;
  const perPersonCapped = Math.min(perPersonRaw, 5000);
  const paidTotal = perPersonCapped * hc;

  return { rows, subtotal, perPersonRaw, perPersonCapped, paidTotal, headcount: hc };
}

export interface SalesPaceResult {
  daily: { d: number; total: number; isFuture: boolean }[];
  mKey: string;
  dim: number;
  todayNum: number;
  soFarTotal: number;
  daysPassed: number;
  avgPerDay: number;
  forecastTotal: number;
  target: number;
  expectedToDate: number;
  paceGap: number;
  status: string;
  statusCls: 'status-ok' | 'status-low' | 'status-over';
  statusReason: string;
}

export function computeSalesPace(
  mKey: string,
  target: number,
  salesInMonth: SaleEntry[]
): SalesPaceResult {
  const now = new Date();
  const currentMonthKey = todayISO().slice(0, 7);
  const isCurrentMonth = mKey === currentMonthKey;
  const [yy, mm] = mKey.split('-').map(Number);
  const dim = daysInMonth(yy, mm);
  const todayNum = isCurrentMonth ? now.getDate() : dim;

  // Group sales by day
  const dayTotals: Record<number, number> = {};
  salesInMonth.forEach((s) => {
    const parts = s.date.split('-');
    if (parts.length === 3) {
      const day = parseInt(parts[2], 10);
      dayTotals[day] = (dayTotals[day] || 0) + (Number(s.total) || 0);
    }
  });

  const daily = [];
  for (let d = 1; d <= dim; d++) {
    daily.push({
      d,
      total: dayTotals[d] || 0,
      isFuture: isCurrentMonth && d > todayNum,
    });
  }

  const soFar = daily.filter((x) => !x.isFuture);
  const soFarTotal = soFar.reduce((a, x) => a + x.total, 0);
  const daysPassed = Math.min(todayNum, dim);
  const avgPerDay = daysPassed > 0 ? soFarTotal / daysPassed : 0;
  const forecastTotal = isCurrentMonth ? Math.round(avgPerDay * dim) : soFarTotal;
  const expectedToDate = isCurrentMonth ? Math.round((target * daysPassed) / dim) : target;
  const paceGap = soFarTotal - expectedToDate;

  let status = '';
  let statusCls: 'status-ok' | 'status-low' | 'status-over' = 'status-ok';
  let statusReason = '';

  if (!isCurrentMonth) {
    if (target > 0 && soFarTotal >= target) {
      status = 'บรรลุเป้าหมาย';
      statusCls = 'status-ok';
      statusReason = `ยอดขาย ${fmt(soFarTotal)} บ. เกินเป้าหมาย ${fmt(target)} บ.`;
    } else {
      status = 'ไม่ถึงเป้าหมาย';
      statusCls = target > 0 && soFarTotal >= target * 0.9 ? 'status-low' : 'status-over';
      statusReason =
        target > 0
          ? `ยอดขาย ${fmt(soFarTotal)} บ. (${((soFarTotal / target) * 100).toFixed(0)}% ของเป้าหมาย ${fmt(target)} บ.)`
          : `ยอดขายรวม ${fmt(soFarTotal)} บ.`;
    }
  } else if (forecastTotal >= target) {
    status = 'ยอดขายตามเป้า (On Track)';
    statusCls = 'status-ok';
    statusReason =
      paceGap >= 0
        ? `ยอดขายนำแผน +${fmt(Math.abs(paceGap))} บ.`
        : `คาดการณ์สิ้นเดือน ${fmt(forecastTotal)} บ.`;
  } else if (forecastTotal >= target * 0.9) {
    status = 'ยอดขายต่ำกว่าเป้าเล็กน้อย (Slightly Behind)';
    statusCls = 'status-low';
    statusReason = `ยอดขายตามหลังแผน -${fmt(Math.abs(paceGap))} บ.`;
  } else {
    status = 'ต้องเร่งทำยอด (Action Needed)';
    statusCls = 'status-over';
    statusReason = `ตามหลังแผน -${fmt(Math.abs(paceGap))} บ. คาดการณ์ ${fmt(forecastTotal)} บ. (${target > 0 ? ((forecastTotal / target) * 100).toFixed(0) : 0}% ของเป้า)`;
  }

  return {
    daily,
    mKey,
    dim,
    todayNum,
    soFarTotal,
    daysPassed,
    avgPerDay,
    forecastTotal,
    target,
    expectedToDate,
    paceGap,
    status,
    statusCls,
    statusReason,
  };
}

export interface CommissionPlanResult {
  pct: number;
  soFarTotal: number;
  target: number;
  pcCount: number;
  tierRate: number;
  tierDesc: string;
  tierAmount: number;
  gallonTotal: number;
  gallonEligibleQty: number;
  grandTotal: number;
  grandPerPerson: number;
}

export function computeCommissionPlan(
  mKey: string,
  target: number,
  pcCount: number,
  monthSales: SaleEntry[],
  gallonRules?: GallonIncentiveRule[]
): CommissionPlanResult {
  const soFarTotal = monthSales.reduce((a, s) => a + (Number(s.total) || 0), 0);
  const pct = target > 0 ? (soFarTotal / target) * 100 : 0;

  // Determine Tier Rate
  let tierRate = 0;
  let tierDesc = 'ต่ำกว่า 80% (ไม่มีค่าคอม)';

  if (pct >= 120) {
    tierRate = 2.0;
    tierDesc = 'ยอดขาย ≥ 120%';
  } else if (pct >= 110) {
    tierRate = 1.75;
    tierDesc = 'ยอดขาย 110% - 119%';
  } else if (pct >= 100) {
    tierRate = 1.5;
    tierDesc = 'ยอดขาย 100% - 109%';
  } else if (pct >= 90) {
    tierRate = 1.0;
    tierDesc = 'ยอดขาย 90% - 99%';
  } else if (pct >= 80) {
    tierRate = 0.5;
    tierDesc = 'ยอดขาย 80% - 89%';
  }

  const tierAmount = Math.round((soFarTotal * tierRate) / 100);

  // Gallon incentive
  let gallonTotal = 0;
  let gallonEligibleQty = 0;

  monthSales.forEach((s) => {
    const q = Number(s.qty) || 0;
    const size = s.size || '';
    let rate = 0;
    if (size.includes('5GL') || size.includes('5 GL') || size.includes('ถังใหญ่')) {
      rate = 50;
    } else if (size.includes('2.5GL') || size.includes('2.5 GL')) {
      rate = 30;
    } else if (size.includes('1GL') || size.includes('1 GL') || size.includes('แกลลอน')) {
      rate = 15;
    } else if (size.includes('1/4') || size.includes('กระป๋อง')) {
      rate = 5;
    }

    if (rate > 0) {
      gallonEligibleQty += q;
      gallonTotal += q * rate;
    }
  });

  const hc = pcCount > 0 ? pcCount : 1;
  const grandTotal = tierAmount + gallonTotal;
  const grandPerPerson = Math.round(grandTotal / hc);

  return {
    pct,
    soFarTotal,
    target,
    pcCount: hc,
    tierRate,
    tierDesc,
    tierAmount,
    gallonTotal,
    gallonEligibleQty,
    grandTotal,
    grandPerPerson,
  };
}
