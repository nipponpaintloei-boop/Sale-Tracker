export interface Product {
  sku: string;
  name: string;
  size: string;
  base: string;
  price: number;
  init: number;
  inflow: number;
  sold: number;
  remain: number;
  seed?: boolean;
  stock?: number;
  currentStock?: number;
  minStock?: number;
  id?: string;
  category?: string;
}

export interface SaleEntry {
  id: string;
  date: string;
  name: string;
  size: string;
  base: string;
  price: number;
  colorCode: string;
  tintPrice: number;
  qty: number;
  total: number;
  sku: string;
  seed?: boolean;
  billId?: string | null;
  customerName?: string;
  customerPhone?: string;
}

export interface SalesRowSupabase {
  id: string;
  date: string;
  name: string;
  size: string;
  base: string;
  price: number;
  color_code: string;
  tint_price: number;
  qty: number;
  total: number;
  sku: string;
  seed: boolean;
  bill_id: string | null;
  customer_name: string;
  customer_phone: string;
}

export interface GallonIncentiveRule {
  id?: string;
  name: string;
  size: string;
  base: string | string[]; // '__ALL__' or specific base(s)
  mode?: 'perUnit' | 'perBundle';
  bundleSize?: number;
  value?: number; // Baht per unit or per bundle
  ratePerCan?: number;
  label?: string;
  desc?: string;
  rate?: number;
}

export interface AppSettings {
  targets: Record<string, number>;
  headcounts?: Record<string, number>;
  pcCount?: Record<string, number>;
  gallonRules?: GallonIncentiveRule[];
  pinhash?: string;
  pin?: string;
  auditLog?: AuditItem[];
  gallonIncentives?: Record<string, GallonIncentiveRule[]>;
  orderByName?: string;
}


export interface AuditItem {
  time: string;
  action: string;
  detail: string;
  flagged?: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user?: string;
  action: string;
  details: string;
}

export interface CustomerMeta {
  favorite?: boolean;
  color?: string | null;
  notes?: string;
  repeatCycleDays?: number;
  name?: string;
  phone?: string;
}

export interface CustomerRecord {
  key: string;
  name: string;
  phone: string;
  total: number;
  count: number;
  lastDate: string;
  favorite: boolean;
  color: string | null;
  note?: string;
  tags?: string[];
  billCount: number;
  billsList: {
    billKey: string;
    date: string;
    total: number;
    items: { name: string; size: string; base: string; qty: number; total: number }[];
  }[];
  topProducts: { name: string; qty: number }[];
  boughtNames: string[];
  avgCycleDays: number | null;
  daysSinceLast: number;
  followStatus: 'overdue' | 'due' | 'ok' | 'new';
  meta?: CustomerMeta;
  totalSpent?: number;
  totalOrders?: number;
  lastOrderDate?: string;
  nextFollowUp?: string;
}

export type CustomerSummary = CustomerRecord;
export type CustomerAggregated = CustomerRecord;

export interface CommissionTier {
  pct: number;
  amt: number;
}

export interface CommissionPerHeadTier {
  min: number;
  amt: number;
}

export interface BrandConfig {
  brandName: string;
  shortName: string;
  monthlyTarget: number;
  commissionMainTable: CommissionTier[];
  commissionSpecialTable: CommissionTier[];
  commissionPerHeadTable: CommissionPerHeadTier[];
  initialCatalogChoice?: 'seed' | 'empty';
  updatedAt?: string;
}

export interface MksBrand {
  key: string;
  label: string;
  us?: boolean;
  pc?: number;
  target?: number;
}

export interface MksDayRow {
  pc: number;
  sales: number;
  note?: string;
}

export interface MksWeekRow {
  pcReg: number;
  pcPro: number;
  target: number;
  sales: number;
  note?: string;
}

export interface MksDayData {
  date: string;
  rows: Record<string, MksDayRow>;
}

export interface MksWeekData {
  from: string;
  to: string;
  rows: Record<string, MksWeekRow>;
}

export interface ActionItem {
  priority: 1 | 2 | 3;
  icon: string;
  view: string;
  title: string;
  detail: string;
}

export interface CommissionBreakdown {
  pct: number;
  main: number;
  special: number;
  perHead: number;
  perPersonSales: number;
  headcount: number;
  monthGoalReached: boolean;
  total: number;
  inSpecialBand: boolean;
}

export interface GallonIncentiveResult {
  rows: {
    rule: GallonIncentiveRule;
    qty: number;
    amount: number;
  }[];
  subtotal: number;
  perPersonRaw: number;
  perPersonCapped: number;
  paidTotal: number;
  headcount: number;
}

export interface SalesPaceStatus {
  statusCls: 'status-over' | 'status-low' | 'status-ok' | 'status-high';
  statusLabel: string;
  statusReason: string;
  expectedSalesToDate: number;
  salesToDate: number;
  gapSales: number;
  dailyNeededRemaining: number;
  daysElapsed: number;
  daysRemaining: number;
  daysInMonth: number;
  target: number;
}
