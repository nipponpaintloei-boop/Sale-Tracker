import { MksBrand } from '../types';

export const STORE_KEYS = {
  products: 'tint:products',
  sales: 'tint:sales',
  settings: 'tint:settings',
  mksDay: 'tint:mksDay',
  mksWeek: 'tint:mksWeek',
  customers: 'tint:customers',
};

export const LOCAL_STORAGE_PREFIX = 'nippon-sale:';

export const DEFAULT_TARGET = 380000;

export const COMMISSION_MAIN_TABLE = [
  { pct: 80, amt: 6000 },
  { pct: 85, amt: 6500 },
  { pct: 90, amt: 7000 },
  { pct: 95, amt: 7500 },
  { pct: 100, amt: 10000 },
  { pct: 105, amt: 11000 },
  { pct: 110, amt: 12000 },
  { pct: 115, amt: 13000 },
  { pct: 120, amt: 14250 },
  { pct: 125, amt: 15500 },
  { pct: 130, amt: 16750 },
];

/* Special Band: 200,000 - 400,000 */
export const COMMISSION_SPECIAL_TABLE = [
  { pct: 80, amt: 1000 },
  { pct: 90, amt: 1500 },
  { pct: 100, amt: 2000 },
];

/* Per-head: sale per person >= 200,000 */
export const COMMISSION_PERHEAD_TABLE = [
  { min: 400000, amt: 3000 },
  { min: 350000, amt: 2500 },
  { min: 300000, amt: 2000 },
  { min: 250000, amt: 1500 },
  { min: 200000, amt: 1000 },
  { min: 150000, amt: 0 },
];

export const THAI_MONTHS = [
  'มกราคม',
  'กุมภาพันธ์',
  'มีนาคม',
  'เมษายน',
  'พฤษภาคม',
  'มิถุนายน',
  'กรกฎาคม',
  'สิงหาคม',
  'กันยายน',
  'ตุลาคม',
  'พฤศจิกายน',
  'ธันวาคม',
];

export const MKS_BRANDS: MksBrand[] = [
  { key: 'NIPPON', label: 'NIPPON (เรา)', us: true, pc: 2, target: 380000 },
  { key: 'TOA', label: 'TOA', pc: 2, target: 1150000 },
  { key: 'BEGER', label: 'BEGER', pc: 2, target: 550000 },
  { key: 'JOTUN', label: 'JOTUN', pc: 1, target: 170000 },
  { key: 'CAPTAIN', label: 'CAPTAIN', pc: 2, target: 380000 },
  { key: 'DELTA', label: 'DELTA', pc: 2, target: 330000 },
  { key: 'DULUX', label: 'DULUX', pc: 1, target: 220000 },
  { key: 'JBP', label: 'JBP', pc: 2, target: 350000 },
];

export const CUST_COLOR_PALETTE = [
  { key: 'ochre', val: '#f0b23c', label: 'ทองโอเคอร์' },
  { key: 'teal', val: '#5f8fd8', label: 'ฟ้าน้ำทะเล' },
  { key: 'clay', val: '#d35b4e', label: 'ส้มดินเผา' },
  { key: 'moss', val: '#7cbf72', label: 'เขียวมอส' },
];

export const RECENT_EDIT_ACTIONS = [
  'นำเข้า Excel',
  'เพิ่มรายการขาย',
  'แก้ไขรายการขาย',
  'ลบรายการขาย',
  'เติมสต็อก',
  'ปรับสต็อก',
  'แก้ไขข้อมูลสินค้า',
];

export const COMMISSION_TIERS = [
  { minPct: 120, maxPct: null, rate: 2.0, label: 'บรรลุตั้งแต่ 120% ขึ้นไป' },
  { minPct: 110, maxPct: 120, rate: 1.75, label: 'บรรลุ 110% - 119%' },
  { minPct: 100, maxPct: 110, rate: 1.5, label: 'บรรลุ 100% - 109%' },
  { minPct: 90, maxPct: 100, rate: 1.0, label: 'บรรลุ 90% - 99%' },
  { minPct: 80, maxPct: 90, rate: 0.5, label: 'บรรลุ 80% - 89%' },
  { minPct: 0, maxPct: 80, rate: 0.0, label: 'ต่ำกว่า 80% (ไม่มีค่าคอมมิชชั่น)' },
];

export const GALLON_TIERS = [
  { size: '5GL', rate: 50, label: 'ถังใหญ่ (5GL / ถังกลม)', desc: 'สีถังใหญ่ขนาด 5 แกลลอน' },
  { size: '2.5GL', rate: 30, label: 'ถังกลาง (2.5GL)', desc: 'สีถังขนาด 2.5 แกลลอน' },
  { size: '1GL', rate: 15, label: 'แกลลอน (1GL)', desc: 'สีถังขนาด 1 แกลลอน' },
  { size: '1/4GL', rate: 5, label: 'กระป๋อง (1/4GL)', desc: 'สีกระป๋องเล็กขนาด 1/4 แกลลอน' },
];
