import React, { useState } from 'react';
import { Sliders, Save, X, RotateCcw } from 'lucide-react';
import { useAppState } from '../../context/AppStateContext';
import { GALLON_TIERS } from '../../data/constants';

interface GallonRuleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GallonRuleModal: React.FC<GallonRuleModalProps> = ({ isOpen, onClose }) => {
  const { settings, updateSettings } = useAppState();
  const currentRules = settings?.gallonRules || GALLON_TIERS;

  const [rules, setRules] = useState(currentRules);

  if (!isOpen) return null;

  const handleRateChange = (index: number, rate: number) => {
    setRules((prev) =>
      prev.map((r, i) => (i === index ? { ...r, rate: Number(rate) || 0 } : r))
    );
  };

  const handleResetDefaults = () => {
    setRules(GALLON_TIERS);
  };

  const handleSave = async () => {
    await updateSettings({ gallonRules: rules });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-orange-100 dark:bg-orange-950 text-orange-600">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                ตั้งเกณฑ์เงินรางวัลค่าถัง (Gallon Incentives)
              </h3>
              <p className="text-xs text-slate-400">กำหนดอัตราเงินรางวัลตามขนาดบรรจุภัณฑ์</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          {rules.map((rule, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/60 text-xs"
            >
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">{rule.label}</span>
                <span className="text-[11px] text-slate-400">{rule.desc}</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0"
                  value={rule.rate}
                  onChange={(e) => handleRateChange(idx, Number(e.target.value))}
                  className="w-20 text-center px-2 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold"
                />
                <span className="text-slate-500 font-medium">บาท/ถัง</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>คืนค่าเริ่มต้น</span>
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold text-xs"
            >
              ยกเลิก
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Save className="w-4 h-4" />
              <span>บันทึกเกณฑ์</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
