import React, { useMemo } from 'react';
import {
  Award,
  Users,
  Layers,
  ChevronRight,
  TrendingUp,
  Target,
  Sparkles,
  DollarSign,
  Sliders,
} from 'lucide-react';
import { useAppState } from '../../context/AppStateContext';
import {
  computeCommissionPlan,
  fmt,
  thaiMonthYear,
} from '../../services/calculations';
import { DEFAULT_TARGET } from '../../data/seedData';
import { COMMISSION_TIERS, GALLON_TIERS } from '../../data/constants';

interface CommissionViewProps {
  onOpenTargetModal: () => void;
  onOpenGallonRuleModal: () => void;
}

export const CommissionView: React.FC<CommissionViewProps> = ({
  onOpenTargetModal,
  onOpenGallonRuleModal,
}) => {
  const { sales, settings, activeMonth } = useAppState();

  const monthSales = useMemo(() => {
    return sales.filter((s) => s.date.startsWith(activeMonth));
  }, [sales, activeMonth]);

  const target = settings?.targets?.[activeMonth] || DEFAULT_TARGET;
  const pcCount = settings?.pcCount?.[activeMonth] || 1;

  const plan = useMemo(() => {
    return computeCommissionPlan(activeMonth, target, pcCount, monthSales, settings?.gallonRules);
  }, [activeMonth, target, pcCount, monthSales, settings]);

  return (
    <div className="space-y-6 max-w-6xl mx-auto pb-24 lg:pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-red-600 uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ระบบคำนวณเงินรางวัลและค่าถัง</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            ผลตอบแทนและคอมมิชชั่น PC (Incentives)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            ประจำเดือน {thaiMonthYear(activeMonth)} | แบ่งตามจำนวน PC {pcCount} คน
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenTargetModal}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Target className="w-4 h-4 text-emerald-500" />
            <span>ปรับเป้า & PC</span>
          </button>
          <button
            onClick={onOpenGallonRuleModal}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sliders className="w-4 h-4 text-amber-500" />
            <span>เกณฑ์ค่าถัง</span>
          </button>
        </div>
      </div>

      {/* Hero 3 Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
        {/* Total Grand Incentives */}
        <div className="bg-gradient-to-br from-red-600 via-rose-600 to-red-700 text-white rounded-3xl p-6 shadow-lg shadow-red-600/20 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-bold text-red-200 uppercase tracking-wider">
            <span>ผลตอบแทนรวมทีม</span>
            <Award className="w-5 h-5 text-white/90" />
          </div>
          <div className="my-4">
            <div className="text-3xl lg:text-4xl font-black font-mono tracking-tight text-white">
              {fmt(plan.grandTotal)}{' '}
              <span className="text-sm font-semibold text-red-200">บาท</span>
            </div>
            <div className="text-xs text-red-100 mt-2">
              เฉลี่ยต่อคน ({pcCount} PC):{' '}
              <b className="font-mono font-black text-white text-sm">
                {fmt(plan.grandPerPerson)}
              </b>{' '}
              บาท
            </div>
          </div>
          <div className="pt-3 border-t border-white/20 text-[11px] text-red-100 flex items-center justify-between">
            <span>ขั้นบรรลุ: {plan.tierDesc}</span>
            <span>Ach: {plan.pct.toFixed(1)}%</span>
          </div>
        </div>

        {/* Tier Rate Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>คอมมิชชั่นตามขั้น (% Ach)</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="my-4">
            <div className="text-3xl font-black text-slate-900 dark:text-white font-mono">
              {fmt(plan.tierAmount)}{' '}
              <span className="text-xs font-medium text-slate-400">บาท</span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              อัตราคอมมิชชั่น: <b className="font-mono text-emerald-600">{plan.tierRate}%</b>{' '}
              ({plan.tierDesc})
            </p>
          </div>
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>ยอดขายสะสมเดือนนี้:</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
              {fmt(plan.soFarTotal)} บ.
            </span>
          </div>
        </div>

        {/* Gallon Incentives Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold uppercase tracking-wider">
            <span>เงินรางวัลพิเศษค่าถัง</span>
            <Layers className="w-4 h-4 text-amber-500" />
          </div>
          <div className="my-4">
            <div className="text-3xl font-black text-slate-900 dark:text-white font-mono">
              {fmt(plan.gallonTotal)}{' '}
              <span className="text-xs font-medium text-slate-400">บาท</span>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              จำนวนขายที่ได้สิทธิ์: <b className="font-mono text-amber-600">{plan.gallonEligibleQty}</b>{' '}
              ถัง
            </p>
          </div>
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>เฉลี่ยต่อคน:</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
              {fmt(plan.gallonTotal / Math.max(1, pcCount))} บ.
            </span>
          </div>
        </div>
      </div>

      {/* Tier Table & Details Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Commission Tiers Schedule */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              ตารางขั้นอัตราคอมมิชชั่น (Achievement Tier)
            </h3>
            <span className="text-xs font-mono font-bold text-red-600">
              ปัจจุบัน {plan.pct.toFixed(1)}%
            </span>
          </div>

          <div className="space-y-2">
            {COMMISSION_TIERS.map((tier, idx) => {
              const isCurrent =
                plan.pct >= tier.minPct && (tier.maxPct === null || plan.pct < tier.maxPct);
              return (
                <div
                  key={idx}
                  className={`flex items-center justify-between p-3 rounded-2xl text-xs font-semibold transition-all ${
                    isCurrent
                      ? 'bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300'
                      : 'bg-slate-50 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {isCurrent && <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />}
                    <span>{tier.label}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-mono font-bold text-sm">
                      {tier.rate > 0 ? `${tier.rate}%` : 'ไม่มีค่าคอม'}
                    </span>
                    {isCurrent && (
                      <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold">
                        ขั้นปัจจุบัน
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Gallon Tiers Breakdown */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              เกณฑ์ค่าถังมาตรฐาน (Gallon Incentives)
            </h3>
            <span className="text-xs text-slate-400">อัตราตามขนาดบรรจุ</span>
          </div>

          <div className="space-y-2">
            {GALLON_TIERS.map((tier, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 text-xs font-medium"
              >
                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block">
                    {tier.label}
                  </span>
                  <span className="text-[11px] text-slate-400">{tier.desc}</span>
                </div>
                <div className="font-mono font-bold text-amber-600 text-sm">
                  {tier.rate} บาท/ถัง
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
